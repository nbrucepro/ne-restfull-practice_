const jwt = require('jsonwebtoken');

const authMiddleware = (req, res, next) => {
  // Get the token from the request headers
  const token = req.headers.authorization;
    console.log(token)
  if (!token) {
    return res.status(401).json({ message: 'No token, authorization denied' });
  }
 
  try {
    // Verify and decode the token
    const decoded = jwt.verify(token, 'jwt-secret');

    // Attach the user ID to the request object
    req.userId = decoded.id;
    next();
  } catch (err) {    
    return res.status(401).json({ message: 'Invalid token' });
  }
};

module.exports = authMiddleware;
